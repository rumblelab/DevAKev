"""include all classes"""
from adafruit_character_lcd.character_lcd import Character_LCD, Character_LCD_I2C, Character_LCD_SPI
from adafruit_character_lcd.character_lcd_rgb import Character_LCD_RGB
